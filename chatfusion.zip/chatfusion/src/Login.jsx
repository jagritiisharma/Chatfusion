import React, { useState } from "react";
import { Link, useNavigate } from 'react-router-dom';
const Login =()=>{
    const [username, setUsername] = useState("");
    const [emaillog, setEmaillog] = useState("");
    const [passwordlog, setPasswordlog] = useState("");
    const [error,setError] = useState("");
    const navigate = useNavigate();
    const handleLogin = () => {
        if ( username==='jagriti' && emaillog === "jagritish638@gmail.com" && passwordlog === "12345") {
            navigate(`/Home?email=${emaillog}`);
        }
        else if (username==="" && emaillog === "" && passwordlog === "") {
          alert("please Provide credentials ");
          navigate('/Login');
        }
        else{
            setError("invalid credentials");
            navigate('/Login');
        }
    }
    return(
        <div className="formContainer">
            <div className="formWrapper">
            <span className="logo"> ChatFusion</span>
                <span className="title">Login</span>
               <form>
                <input type="text" placeholder="username" value={username} onChange={(e)=>setUsername(e.target.value)}></input>
                <input type="email" placeholder="email" onChange={(event) => setEmaillog(event.target.value)}></input>
                <input type="password" placeholder="password" onChange={(event) => setPasswordlog(event.target.value)}></input>
                <div>
                {error && <p style={{color:"red"}}>error</p>}
                <Link to='/Home'>
                <button onClick={handleLogin}>Sign in</button>
                </Link>
                </div>
               </form>
               <p>you don't have an account? 
               <Link className='link' to='/Register'>
                                    <li type="none">Register</li>
                                </Link>  </p>
            </div>
        </div>
    )
}
export default Login;