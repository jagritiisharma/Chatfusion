import Register from './Register';
// import style from './style.scss'
import style from './style.scss'
// import './App.css.scss';
import Login from './Login';
import Home from './Home';
import Chat from './Chat';
import Search from './Search';
import Navbar from './Navbar';
import Input from './Input';
import Message from './Message';
import Chats from './Chats';
import component from './Component';
import { BrowserRouter as Router, Routes ,Route } from 'react-router-dom';
// import { Router, Routes,Route } from 'react-router-dom';
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Register/>}></Route>
        <Route path="/Register" element={<Register/>}></Route>
        <Route path="/Login" element={<Login/>}></Route>
        <Route path="/Home" element={<Home/>}></Route>
      </Routes>
    </Router>
  );
}

export default App;
