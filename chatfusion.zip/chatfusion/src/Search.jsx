import React from 'react'
import image from './img.jpg'
const Search = () => {
  return (
    <div className='search'>
    <div className='searchForm' >
    <input type="text" placeholder="find a user"></input>
   
    </div>
    {/* <img src='img.jpg' alt=""></img> */}
   <div className='userChat'>
   <img src={image}></img>
   <div className="userChatInfo">
    <span>jagriti</span>
   </div>
    </div>
    </div>
  )
}

export default Search;
