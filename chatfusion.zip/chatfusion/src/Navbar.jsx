import React from 'react'
import {Link} from 'react-router-dom';
import img from './img.jpg';
const Navbar = () => {
  return (
    <div className='navbar'>
     <span className='logo'>WeChat</span>
     <div className='user'>
      <img src={img} alt=""></img>
      <span>Jagriti</span>
      <div><Link to='/Login'>
      <button>logout</button>
      </Link>
      </div>
     </div>
    </div>
  )
}

export default Navbar;
