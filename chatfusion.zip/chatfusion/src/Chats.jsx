import React from 'react'
import akku from './akku.jpg';
// import Chat from './Chat';
const Chats = () => {
    return (
        <div className="chats">
            <div className="userChat">
                <img src="https://images.pexels.com/photos/144474/pexels-photo-144474.jpeg?auto=compress&cs=tinysrgb&w=600" alt="" />
                <div className="userChatInfo">
                    <span>Ankit</span>
                    <p>Hello</p>
                </div>
            </div>
            <div className="userChat">
                <img src={akku} alt="" />
                <div className="userChatInfo">
                    <span>Akanksha</span>
                    <p>what's up</p>
                </div>
            </div>
            <div className="userChat">
                <img src="https://images.pexels.com/photos/18165273/pexels-photo-18165273.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load" alt="" />
                <div className="userChatInfo">
                    <span>Anshi</span>
                    <p>Okay</p>
                </div>
            </div>
            <div className="userChat">
                <img src="https://images.pexels.com/photos/14934612/pexels-photo-14934612.jpeg?auto=compress&cs=tinysrgb&w=600" alt="" />
                <div className="userChatInfo">
                    <span>Abhishek</span>
                    <p>yess</p>
                </div>
            </div>
            
        </div>
    )
}
export default Chats;
