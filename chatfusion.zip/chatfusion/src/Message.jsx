import React from 'react'
import img from './img.jpg'
const Message = () => {
  return (
    <div className='message owner'>
      <div className='messageInfo'>
      <img src={img}></img>
      <span>just now</span>
      </div>
      <div className='messageContent'>
        <p>hello how are you</p>
      </div>
    </div>
  )
}

 export default Message;


