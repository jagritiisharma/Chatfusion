import React from "react";
import  gallery from './gallery.png';
import  attach from './attach.png';


const Input = () =>{
    return(
       <div className="input">
        <input type="text" placeholder="Type Something.."/>
        <div className="send">
            <img src={attach}/>
            <input type="file" style={{display:"none"}} id="file" />
            <label htmlFor="file">
                <img src={gallery} alt="" />
            </label>
            <button>Send</button>
        </div>
       </div> 
    )
}

export default Input;