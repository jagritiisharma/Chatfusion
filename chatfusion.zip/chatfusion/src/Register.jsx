import React from "react";
import gallery from "./gallery.png";
import {Link} from 'react-router-dom';
const Register =()=>{
    return(
        <div className="formContainer">
        <div className="formWrapper">
        <span className="logo">WeChat</span>
            <span className="title">Register</span>
           <form>
            <input type="text" placeholder="display name"></input>
            <input type="email" placeholder="email"></input>
            <input type="password" placeholder="password"></input>
            <input style={{display:"none"}}type="file"id="file"></input>
            <label htmlFor="file">
               <img src={gallery} alt=""></img>
               <span>add an avatar</span>
            </label>
            <button>Sign up</button>
           </form>
           <p>you don't have an account? 
           <Link className='link' to='/Login'>
                                <li type="none">Login</li>
                            </Link>  </p>
        </div>
    </div>
    )
}
export default Register;