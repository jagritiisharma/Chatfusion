import React from "react";
import Sidebar from "./Sidebar";
import Chat from "./Chat";
const Home=()=> {
    return(
        <div className="home">
         <div className="container">
         {/* <h1>hello</h1> */}
         <Sidebar></Sidebar>
         <Chat></Chat> 
           
        </div>
        </div>
    )
}
export default Home;